// src/options.ts
var el = document.getElementById("status");
function render(connected) {
  if (connected) {
    el.innerHTML = '<span class="dot green"></span>Connected to xcsh';
  } else {
    el.innerHTML = '<span class="dot red"></span>Not connected — start xcsh and run <code>xcsh chrome setup</code>';
  }
}
chrome.runtime.sendMessage({ type: "status_request" }, (resp) => {
  if (chrome.runtime.lastError) {
    render(false);
    return;
  }
  render(!!resp?.connected);
});
